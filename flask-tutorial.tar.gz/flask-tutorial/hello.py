#from flask import Flask

#app = Flask(__name__)

#
#@app.route('/')
#def hello():
#    return 'Hello, World!'

#import click

#@click.command()
#@click.option('--count', default=1, help='Number of greetings.')
#@click.option('--name', default="John", help='The person to greet.')
#def hello(count, name):
#    """Simple program that greets NAME for a total of COUNT times."""
#    for x in range(count):
#        click.echo(f"Hello {name}!")

#if __name__ == '__main__':
#    hello()


import sqlite3

con = sqlite3.connect("tutorial.db")

cur = con.cursor()

cur.execute("CREATE TABLE movie(title, year, score)")

res = cur.execute("SELECT name FROM sqlite_master")

res.fetchone()


